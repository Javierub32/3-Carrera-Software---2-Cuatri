<%--
  Created by IntelliJ IDEA.
  User: javie
  Date: 02/03/2026
  Time: 11:17
  To change this template use File | Settings | File Templates.
--%>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Title</title>
</head>
<body>
<h1>El resultado es ${solucion}</h1>


</body>
</html>
