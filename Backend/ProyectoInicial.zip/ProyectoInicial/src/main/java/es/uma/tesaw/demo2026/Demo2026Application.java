package es.uma.tesaw.demo2026;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demo2026Application {

    public static void main(String[] args) {
        SpringApplication.run(Demo2026Application.class, args);
    }

}
